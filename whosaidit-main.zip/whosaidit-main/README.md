# whosaidit
 Python Discord Bot - guess who said it - famous quotes from famous sitcoms
