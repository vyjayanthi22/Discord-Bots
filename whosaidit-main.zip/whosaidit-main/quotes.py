quotes = {}

quotes['friends'] = {
	'chandler' : [
		"I say more dumb things before 9 A.M. than most people say all day.",
		" 'I got her machine.' Joey: Her answering machine? 'No. Interestingly enough her leafblower picked up.' '",
		"I’m funny, right? What do you know? You’re a door. You only like knock-knock jokes.",
		"Ross: I went to that tanning place your wife suggested. 'Was that place the sun?' ",
		"You have to stop the q-tip when there’s resistance!",
		"And yet I never run into Beyonce.",
		"No, you didn’t get me. It’s an electric drill, if you get me, you kill me!",
		"So it seems like this internet thing is here to stay.",
		"I’m not great at the advice. Can I interest you in a sarcastic comment?",
		"She's right. If I were a guy and... did I just say, 'If I were a guy'?",
		"I’m a gym member. I try to go four times a week, but I’ve missed the last twelve hundred times.",
		"Until I was 25, I thought that the only response to ‘I love you’ Was ‘Oh, crap!'",
		"Could we be more white trash?",
		"I tend to keep talking until somebody stops me.",
		"What must it be like not to be crippled by fear and self-loathing?",
		"When I first meet somebody it’s usually panic, anxiety, and a great deal of sweating.",
		"It’s always better to lie than to have the complicated discussion.",
		"Well, maybe he was nervous",
		"I’m glad we’re having a rehearsal dinner, I rarely practice my meals before I eat.",
		"SHUT UP. SHUT UP. SHUT UP.",
		"Why yes Ross, pressing my third nipple. It opens the delivery entrance to the magical land of Narnia.",
		"I'm hopeless and awkward and desperate for love!",
		"I’m sorry we, we don’t have your sheep.",
		"The fifth dentist caved and now they’re all recommending trident?",
		"Dear God! This parachute is a knapsack!",
		"Ah. So how many cameras are actually on you?",
		"What did I marry into?!",
		"At what point did you think this was a successful marriage?",
		"I know. This must be so hard. 'Oh, no. Two women love me. They're both gorgeous, my wallet's too small for my 50s, and my diamond shoes are too tight.'",
		"Rachael: You idiot! 'I'm sure you're right but why?''",
		"I am not a Blah, I am a HOOT!",
		"I can handle this. “Handle” is my middle name. Actually, “handle” is the middle of my first name.",
		"Because you’ve only known her for six weeks. I’ve got a carton of milk in my refrigerator I’ve had a longer relationship with.",
		"Well, actually, yesterday I was smoking again. Today, I’m smoking still.",
		"I’m a headhunter. I hook up out-of-work Soviet scientists with rogue third-world nations. Hi, Rasputin!",
		"Before or after you’re executed by your own troops?",
		"I don’t think you can make that statement, unless you’ve been kicked in the area, God only meant to be treated nicely.",
		"What kind of scary clowns came to your birthday?",
		"An 80-foot inflatable dog loose over the city? How often does that happen?",
		"So how many cameras are actually on you?"
	],
	'ross' : [
		"Unagi is a total state of awareness.",
		"You-you-you... you threw my sandwich away...",
		"I don’t know. It’s got all this stuff about wind and trees…and there is some sacred pool in it. I don’t really get it. But she’s pretty upset about it.",
		"We were on a break!",
		"Pivot. Pivot. Piv-ot. Piv-ot. PIVOT!",
		"Oh my God! Did she get off the plane? Did she get off the plane?",
		"You sprayed my front twice!",
		"What? Okay, Phoebe, this is it. In this briefcase, I carry actual scientific facts. A briefcase of facts, if you will. Some of these fossils are over 200 million years old.",
		"No need to point. She knows who Ross is.",
		"First marriage, wife’s hidden sexuality, not my fault. Second marriage, said the wrong name at the altar, a little my fault. Third marriage… Well they really shouldn’t allow you to get married when you’re that drunk and have writing all over your face, Nevada’s fault.",
		"I thought you were my best friend, this is my sister! My best friend and my sister! I cannot believe this!",
		"No! I barely even got to three Mississippi.",
		"They’re still, they’re still not coming on man and the lotion and the powder have made a paste!",
		"Sure, just lend me your breasts and we’ll be on our way.",
		"Well, Hurricane Gloria didn’t break the porch swing. Monica did.",
		"This is just classic Rachel! You’re off in Rachel-land with no thought for people’s feelings or monkeys!",
		"So, I don’t know if he’s testing me or just acting out, but my monkey is out of control! He keeps erasing the messages on my machine!",
		"You know, we should probably ask the doctor if she even knows how to deliver a baby that’s half-human, half pure evil.",
		"Wow. This is the first time I’ve walked down the aisle without the possibility of it ending in divorce.",
		"A no-sex pact, huh? I seem to have one of those going with every woman in America.",
		"You know what the scariest part is? What if there’s only one woman for everybody, you know? I mean, what if you get one woman, and that’s it? Unfortunately, in my case, it was only one woman for her.",
		"I honestly don’t know if I’m hungry or horny.",
		"Yes. yes, it is... in prison!",
		"I am this close to tugging on my testicles again.",
		"Ah. Humour based on my pain.",
		"I tell you, when I actually die, sme people are going to get seriously haunted!",
		"I got dumped during sex!",
		"I am a terrible father!",
		"Yup! You could plunk me down in the middle of any woman’s uterus, no compass, and I can find my way out of there like (snaps fingers) that."
	],
	'monica' : [
		"No, you go after them five minutes before they get married.",
		"I needed a plan, a plan to get over my man. And what’s opposite of man? Jam.",
		"It’s never taken you more than a shower to get over a relationship.",
		"I’ve got this uncontrollable need to please people."	
	],
	'joey' : [
		"I… I think I’m falling in love with you.",
		"OK. So I’m out $4,000 and nobody’s boobs are getting any bigger?",
		"“It’s a moo point. It’s like a cow’s opinion; it doesn’t matter. It’s moo.",
		"Tell me about it. I feel like I’m holding down the fort all by myself.",
		"What’s not to like? Custard, good. Jam, good. Meat, good!",
		"No. Wait, a minute. What was the Little Mermaid?",
		"You are not even man enough to get the channel that carries the sport.",
		"Joey doesn’t share food!",
		"Hey, hey, that tone won’t make me go any faster.",
		"How you doin’?",
		"Man, I’m starving. What was I thinking at dinner? ‘Do you want soup or salad?’ Both. Always order both.",
		"I’m not stealing it. I’m accepting it on her behalf.",
		"I know what it means. It’s a verb. As in, I behalfing it.",
		"Look at me! I’m Chandler! Could I be wearing any more clothes?!",
		"I’m a lone wolf. A loner. Alone. All alone. Forever… …. … What’s a lone wolf gotta do to get a hug around here?!",
		"Oh, I'm sorry. Did I get 'ya?"
	],
	'rachel' : [
		"I broke up with you because I was mad at you, not because I stopped loving you.",
		"To Monica and Chandler! And that knocked-up girl in Ohio!",
		"I’m sorry. Are we having an 89-year-old?",
		"Well, maybe I don’t need your money. Wait, wait! I said, ‘Maybe.'",
		"No, it bothered me when he slept with other women.",
		"I can’t believe I have to walk down the aisle in front of 200 people looking like something you drink when you’re nauseous!",
		"Mon, what am I gonna do? It’s been hours and it won’t stop crying.",
		"Hey, what do you think is a better excuse for why I’m not drinking on this date tonight. I’m a recovering alcoholic, I’m a Mormon, or I got so hammered last night, I’m still a little drunk?",
		"Yeah, but if you spent it, it would be like shopping!",
		"Isn’t this exciting! I earned this! I wiped tables for it, I steamed milk for it, and it was totally… not worth it. Who’s FICA? Why’s he getting all my money?",
		"Yeah, well just be glad he’s not playing a smaller instrument.",
		"Your teeth? Yeah, I saw them from outside."
	],
	'phoebe' : [
		"They don’t know that we know they know we know.",
		"Well, you all know that I am a pacifist which means I am not interested in war — in any way. But when the revolution comes, I will have to destroy you all; not you, Joey.",
		"I can’t have a mimosa? I’m on vacation!",
		"Come on, Ross. You’re a paleontologist, dig a little deeper.",
		"I don’t even have a pla.",
		"I wish I could. But, I don’t want to.",
		"Oh, come on, Will. Just take off your shirt and tell us.",
		"It’s Nestle Toulouse.",
		"Phoebe. That’s, P, as in Phoebe, H, as in hoebe, O as in oebe, E, as in ebe, B, as in bebe, and E as in… Ello there mate.",
		"There’s five hundred extra dollars in my account.",
		"It’s not mine! I didn’t earn it. If I kept it, it would be like stealing!"	
	]
}


# quotes['bbt'] = {
# 	'sheldon' : [

# 	],
# 	'penny' : [

# 	],
# 	'bernadette' : [

# 	],
# 	'amy' : [

# 	],
# 	'leonard' : [

# 	],
# 	'howard' : [

# 	],
# 	'raj' : [

# 	]
# }

# quotes['got'] = {


# }

# quotes['himym'] = {
# 	'zoey' : [

# 	],
# 	'james' : [

# 	],
# 	'barney' : [

# 	],
# 	'lily' : [

# 	],
# 	'ted' : [

# 	],
# 	'victoria' : [

# 	],
# 	'robin' : [

# 	],
# 	'patrice' : [

# 	],
# 	'tracy' : [

# 	],
# 	'marshall' : [

# 	]
# }

quotes['b99'] = {
	'jake' : [
		"Cool, cool, cool, cool, cool. No doubt, no doubt, no doubt.",
		"Fine. But in protest, I'm walking over there extremely slowly",
		"All right, there's the robot I fell in love with.",
		"Don't worry about that, we'll just get you another one- oh, you mean your body water! That's much worse!",
		"I hope it wasn't a mistake,' title of your sex tape? [gasps] Title of our sex tape!",
		"I appealed to their sense of teamwork and camaraderie with a rousing speech that would put Shakespeare to shame.",
		"Well, frankly, I pity the lot of you. You look out there and see a problem, I look out there and see an opportunity. I'm gonna slide on that slippery floor all the way from Holt's office to the elevator.",
		"Yeah. Okay, here it goes. Ames, I love you. I love how smart you are. I love how beautiful you are. I love your face, and I love your butt. I should've written this down first.",
		"I'm so confused I don't know what's happening right now': title of your sex tape.",
		"Great, I'd like your $8-Est bottle of wine, please.",
		"Wait... What? Did you say 'eat people?' Are you a cannibal, Caleb?",
		"I didn't look. And I'm wearing shorts; there is no fly.",
		"Where were you? You were gone for three hours. I know because I sang 'This Is How We Do It' 143 times.",
		"Backstreet Boys. I'm familiar. Okay. [presses intercom] Number one, could you please sing the opening to 'I Want It That Way?",
		"I swear, these perps are so stupid. I'd make a better criminal than any of 'em.",
		"We've busted murderers; we've taken down cartels. But today we face the worst New York has to offer- the Fire Department.",
		"I tried everything. I begged. I pleaded. I even told them that Scully was a Make-a-Wish kid with a rare disease that makes him look like a giant old baby.",
		"That was 18 days ago. He's getting saner by the minute. In a month, he'll basically just be Frasier.",
		"Sarge, with all due respect, I am gonna completely ignore everything you just said."
	],
	'rosa' : [
		"And when this is over, I'm going to find you, and I'm going to break those little fingers.",
		"Cause I didn't understand why people care so much about their dumb dogs till I got a dumb dog myself. I've only had Arlo for a day and a half, but if anything happened to him, I would kill everyone in this room and then myself.",
		"We can go to my apartment. No one knows where I live.",
		"I just forget stuff like a cool person.",
		"Possibly. My immune system is too weak to fight off my smile muscles.",
		"That's my plan for dealing with everything. I have seventy-seven arguments I'm going to win that way.",
		"I'm an archer. I have like six bows in my car.",
		"People I work with all think my name is Rosa Diaz.",
		"My neighbors think my name is Emily Goldfinch.",
		"It's either that or go carolling with my family, so yeah. I'd rather walk into the freezing ocean.",
		"I've only said I love you to three people. My mom, my dad and my dying grandpa. And one of those I regret.",
		"Next time I catch him shaving I'm gonna punch him so hard in the mouth that he bites his own heart.",
		"All smiling is horrible. This is worse.",
		"Plans are plans. I’m a badass, not an anarchist.",
		"Fly to Montreal, check into a classy hotel, bone a stranger. Slump over. That’ll fix it!",
		"What kind of woman doesn’t have an axe?",
		"RoboCop. It’s got everything I like: gratuitous violence…",
		"Anyone over the age of six celebrating a birthday should go to hell.",
		"A place where everybody knows your name is hell. You’re describing hell."
	],
	'gina' : [
		"Captain, turn your greatest weakness into your greatest strength. Like Paris Hilton RE: her sex tape.",
		"All men are at least 30% attracted to me. My mother cried the day I was born, because she knew she would never be better than me.",
		"Jake, why don’t you just do the right thing and jump out of a window?",
		"I was thinking how I would make the perfect American President based upon my skill set, dance ability and blood lust.",
		"Wait, first, let’s say a prayer. Dear Beyonce, Solange, Rihanna, someone cool that’s white, Cardi B, please bless this flush. A-women.",
		"How am I supposed to know there’d be consequences for my actions?",
		"You think you can just bully people, but you can’t. It’s not okay. I’m the bully around here. Ask anyone.",
		"I’d describe the workflow today as dismal with a tiny dash of pathetic.",
		"I’m scared of businessmen. A whole army of gray-suited Brads and Chads trying to suck my soul and redeem it for frequent Flyer Miles.",
		"As everyone knows, my spirit animal is nature’s greatest predator, the wolf.",
		"What? The only thing I’m not good at is modesty, because I’m great at it.",
		"Can you go be depressed over there? You’re bumming out my whole area.",
		"The only reason I didn’t tell you is I don’t value you as people, so why be honest?",
		"I would spend my $5000 to buy backstage passes to Britney, and then I would ask her one question: You think you’re a better dancer than me?",
		"Have you seen Captain Holt? Tall, handsome gentleman dressed like an airline pilot.",
		"If I die, turn my Tweets into a book.",
		"Every time you talk I hear that sound that plays when Pacman dies.",
		"I grew up forging report cards. If people knew how smart I was, it would have been harder to control them.",
		"Amateur. Always say your insults to someone’s face. No paper trail.",
		"I worked at a sunglass kiosk at the mall for four years, so not only have I been through hell, I was assistant manager there."
	],
	'amy' : [
		"Tell me about it. Every time we get emotional, he's like, 'Noice, smort.'",
		"[YELLING] All right, you mooks, our union health plan has 100% reimbursement for out-of-state ambulance rides. Scully will fake a medical emergency.",
		"I may be a liar, but I've got great teeth and no one can take that from me.",
		"I can read him. And if anyone can figure out what's bothering him, it's me. He and I are exactly the same. Except that I'm younger, Cuban, female, single, and straight.",
		"This one says Die Pig. And worst of all, they didn't put the comma between die and pig.",
		"Speech! Short and sweet.",
		"It'll cheer the captain up. He'll be over the moon. He may even lean back in his chair and nod slightly.",
		"Melvin Stermley? He's the best in the game! He made a puzzle once where all the answers were just the word 'puzzle' in different languages. In Estonian, it was moistatus.",
		"Thank you, sir. I can't wait. I didn't mean- Let's catch this bastard.",
		"It's not that weird to say, 'May I have some cocaine?'",
		"He left a tiny crack in the blind, so I could read the Captain's lips. ... My lip-reading is not flawless.",
		"Sir, I would be honored to take on this challenging assignment. [laughter] Why is everyone laughing? I can be a badass.",
		"I'm making a scrapbook of his professional highlights. Newspaper clippings, police reports, pictures. It's got every moment of his career, 'From Ray to Z'.",
		"I got it. We lie, tell him we broke up, then date in secret."
	],
	'charles' : [
		"Jake, piece of advice: just give up. It’s the Boyle way. It’s why our family crest is a white flag.",
		"What about me? What if something happens to Jake, and he never gets to meet my baby?",
		"We called it giving each other road head.",
		"My Nana always said, 'Bad news first because the good news is probably a lie.' Fun fact: she made me cry a lot.",
		"Let me tell you something about Tinker Bell. Tinker Bell is a loyal lieutenant and a real thorn in the side of Captain Hook.",
		"Yeah, I'm not an idiot. I know how to trick my best friend into eating his fiber.",
		"Okay. Imagine a letter had unprotected sex with a phone.",
		"Oh, you're right. I'm gonna tell him. It might not be today. It might not be tomorrow. It definitely won't be later than tomorrow. So pretty much today or tomorrow then.",
		"Are you blackmailing me? I don't have any money, Hitchcock. I'm still paying my uncle's funeral bills. I rear-ended the hearse. It was a mess.",
		"Why did you wake me up?! I told you never to wake me up!",
		"I want to send someone into holding, undercover as a perp, to see if they can get him to open up.",
		"Jake, do you know why little boys pull little girls' pigtails on playgrounds?",

	],
	'raymond' : [
		"No need. I brought these. Nutrition bricks. I have original no flavor, and whole wheat no flavor.",
		"Yes, but my software is due for an exuberance upgrade.",
		"Yes, I never thought I'd see you this high without a broom under you.",
		"Coat, coat, jacket, coat. Is this a police precinct or a Turkish bazaar?",
		"He was a great partner. Smart, loyal, homophobic, but not racist. In those days that was pretty good.",
		"Why'd you do it, Bob? Why'd you betray everything you ever stood for?",
		"In all fairness, Bob, who spells 'Anderson' with three Ns?",
		"I know we live in a world where anything can mean anything, and nobody even cares about etymolo-",
		"Doctor. Huh. It's funny when people call dentists 'doctor'.",
		"Fun? I was never fun. You take that back.",
		"Captain Wuntch. Good to see you. But if you're here, who's guarding Hades?",
		"Love, it sustains you. It’s like oatmeal.",
		"I asked them if they wanted to embarrass you, and they instantly said yes",

	],
	'terry' : [
		"This is taking too long! I'm gonna miss the farmer's market!",
		"I'm playing Kwazy Cupcakes, I'm hydrated as hell, and I'm listening to Sheryl Crow. I've got my own party going on.",
		"You all got a problem with my minivan? Because my wife doesn't like it either. She wanted an SUV, but those things roll, man. They roll!",
		"I'm a detective. I will detect.",
		"Don't use Frasier's name in vain.",
		"The hippo with heads on both ends, that's Hitchcock and Scully.",
		"Jacob Peralta is my best detective. He likes putting away bad guys and he loves solving puzzles. The only puzzle he hasn't solved is how to grow up.",
		"I've talked a lot about Jake in my departmentally-mandated therapy sessions.",
		"Correction, you bring Vacation Terry, and he is no man's boss. When the slippers are filled, Terry is chilled.",
		"Why are you giving candy to a baby in the first place? Don't give candy to a baby! They can't brush their teeth!",
		"Baby, I've got some bad news. Someone painted a giant penis on our minivan. No, you can not have an SUV now. Those things roll, baby, they roll!",
		"Plus it's good team building. We're gonna get through this together. Hey guys, pro tip. Lick the baggie. There's food molecules in there.",
		"Plus, the longer I stay out of my house today, the better. My brother-in-law, Zeke, is in town.",
		"Also teensie Terry, Teeny Weeny Terry Berry, and Little Dumb Dumb. You know, it's that lack of effort on the last one that really gets me.",

	]
}


quotes['office'] = {
	'michael' : [
		"I’m Beyoncé, always.",
		"It’s Britney, bitch.",
		"Would I rather be feared or loved? Easy. Both. I want people to be afraid of how much they love me.",
		"Sometimes I’ll start a sentence and I don’t even know where it’s going. I just hope I find it along the way.",
		"The worst thing about prison was the Dementors. They were flying all over the place and they were scary and they’d come down and they’d suck the soul out of your body and it hurt!",
		"When the son of the deposed king of Nigeria emails you directly, asking for help, you help! His father ran the freaking country! Okay?",
		"I have cause. It is beCAUSE I hate him.",
		"Society teaches us that having feelings and crying is bad and wrong. Well, that’s baloney, because grief isn’t wrong. There’s such a thing as good grief. Just ask Charlie Brown.",
		"You know what they say. Fool me once, strike one, but fool me twice … strike three.",
		"Well, well, well, how the turntables.",
		"I’m not superstitious, but I am a little ‘stitious.",
		"I love inside jokes. I’d love to be a part of one someday.",
		"Wikipedia is the best thing ever. Anyone in the world can write anything they want about any subject. So you know you are getting the best possible information.",
		"I don’t understand. We have a day honoring Martin Luther King, but he didn’t even work here.",
		"And I knew exactly what to do. But in a much more real sense, I had no idea what to do.",
		"I understand nothing.",
		"Well, it’s love at first sight. Actually, it was … No, it was when I heard her voice. It was love at first see with my ears.",
		"Okay, too many different words from coming at me from too many different sentences.",
		"It’s a pimple, Phyllis. Avril Lavigne gets them all the time and she rocks harder than anyone alive.",
		"I would not miss it for the world. But if something else came up I would definitely not go.",
		"That’s what she said."
	],
	'dwight' : [
		"Whenever I'm about to do something, I think 'Would an idiot do that?' And if they would, I do not do that thing.",
		"Who is Justice Beaver?",
		"I love catching people in the act. That's why I always whip open doors.",
		"'R' is among the most menacing of sounds. That's why they call it 'murder' and not 'mukduk'",
		"When someone smiles at me, all I see is a chimpanzee begging for its life.",
		"You better learn your rules. If you don't, you'll be eaten in your sleep.",
		"Why are all these people here? There's too many people on this earth. We need a new plague.",
		"In the end, the greatest snowball isn't a snowball at all. It's fear. Merry Christmas.",
		"All you need is love. False. The four basic human necessities are air, water, food, and shelter.",
		"I am ready to face any challenge that might be foolish enough to face me.",
		"To avoid illness, expose yourself to germs, enabling your immune system to develop antibodies. I don't know why everyone doesn't do this... Maybe they have something against living forever.",
		"In an ideal world I would have all ten fingers on my left hand and the right one would just be left for punching.",
		"Security in this office park is a joke. Last year I came to work with my spud-gun in a duffel bag. I sat at my desk all day with a rifle that shoots potatoes at 60 pounds per square inch. Can you imagine if I was deranged?",
		"I don't believe you, continue.",
		"I overslept. Damn rooster didn't crow.",
		"You couldn't handle my undivided attention.",
		"I saw 'Wedding Crashers' accidentally. I bought a ticket for 'Grizzly Man' and went into the wrong theater. After an hour, I figured I was in the wrong theater but I kept waiting. Cause that's the thing about bear attacks... they come when you least expect it.",
		"I am faster than 80% of all snakes"
	],
	'jim' : [
		"I ate a tuna sandwich on my first day, so then Andy started calling me 'Big Tuna'. I don’t think any of them know my real name.",
		"Fact: Bears eat beets. Bears. Beets. Battlestar Galactica.",
		"Actually I am in an office relationship. It’s special… She’s nice, she’s shy. She’s actually here if you wanna meet her.",
		"I don’t have a lot of contact with the Scranton branch, but before I left I took a box of Dwight’s stationery. So from time to time, I send Dwight faxes… from himself… from the future.",
		"I gotta tell you, this baby is amazing. She gets me out of everything, and I… and I love her. I also love her very much.",
		"My roommate wants to meet everybody. Because I’m pretty sure he thinks I'm making Dwight up. He is very real.",
		"I miss Dwight. Congratulations, universe. You win.",
		"When I tell people I work at Dunder Mifflin, they think that we sell mufflers or muffins or mittens or…and frankly, all of those sound better than paper, so I let it slide.",
		"I had to put more and more nickels in his handset, so he would get used to the weight. Then one day… I took ‘em all out.",
		"He has not stopped working… for a second. At 12:45, he sneezed, while keeping his eyes open, which I always thought was impossible. At 1:32 he peed. And I know that because he did that in an open soda bottle, under the desk, while filling out expense reports. And on the flip side, I’ve been so busy watching him that I haven’t even started work. It’s exhausting, being this vigilant. I’ll probably have to go home early today.",
		"This is 'parkour', the internet sensation of 2004. It was in one of the Bond films. It’s pretty impressive. The point is to get from point A to point B as creatively as possible, so technically they are doing parkour as long as point A is delusion and point B is the hospital.",
		"I mean I’ve always subscribed to the idea that if you really want to impress your boss, you go in there and you do mediocre work, halfheartedly.",
		"Last week, Dwight found half a joint in the parking lot. And as it turns out, Dwight finding drugs is more dangerous than most people using drugs.",
		"You’re looking at the master of leaving parties early.",
		"Now exactly how much pot did you smoke?",
		"One day, Michael came in complaining about a speed bump on the highway. I wonder who he ran over then.",
		"We didn’t play many video games in Scranton. Instead, we’d do stuff like.. uh, Pam and I would sometimes hum the same high-pitched note and try to get Dwight to make an appointment with an ear doctor. And, uh, Pam called it… Pretendinitis.",
		"Right now, this is just a job. If I advance any higher in this company, this would be my career. And, uh, if this were my career, I’d have to throw myself in front of a train.",
		"I am a black belt in gift wrapping.",
		"This is the smallest amount of power I’ve ever seen go to someone’s head.",
		"Oh so Dwight gave me this wooden mallard as a gift. I found a recording device in it. Yes. So. I think if I play it just right, I can get Dwight to live out the plot of National Treasure.",
		"So, I am about to do something very bold in this job that I’ve never done before: try.",
		"Stanley just drank OJ out of my mug and didn’t seem to realize that it wasn’t his hot coffee. So the question has to be asked, is there no limit to what he won’t notice?",
		"I am Bill Buttlicker."
	],
	'pam' : [
		"I did the coal walk, Michael",
		"I'm gonna start telling people what I want, directly.",
		"You couldn't even do that. Maybe I should be your boss.",
		"There's a lot of beauty in ordinary things. Isn't that kind of the point?",
		"I suggested we flip a coin, but Angela said she doesn't like to gamble.",
		"There's nothing better than a beautiful day at the beach.",
		"Of course, by saying that she was gambling that I wouldn’t smack her.",
		"I don't care what they say about me. I just want to eat. Which i realize is a lot to ask for... At a dinner party.",
		"Once every hour, someone is involved in an internet scam.",
		"That man is Michael Scott. He’s supporting about twenty Nigerian princesses.",
		"When you're a kid, you assume your parents are soulmates. My kids are gonna be right about that.",
		"Be strong. Trust Yourself. Love Yourself.",
		"So, look out world, cuz ol’ Pammy is getting’ what she wants. And, don’t call me, Pammy.",
		"And I feel God in this chili's tonight.",
		"Conquer your fears. Just go after what you want and act fast, because life just isn’t that long."
	]
}